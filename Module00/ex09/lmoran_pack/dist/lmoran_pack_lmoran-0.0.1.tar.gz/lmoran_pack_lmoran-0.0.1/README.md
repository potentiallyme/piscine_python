# TEST PACKAGE

This is a fake package for the sake of testing and creating one for 42's Python for Data Science module
